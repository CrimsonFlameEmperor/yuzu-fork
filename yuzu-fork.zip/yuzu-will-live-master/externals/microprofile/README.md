# microprofile

MicroProfile is a embeddable profiler in a single file, written in C++

It can display profile information in the application, or by generating captures via a minimal built in webserver.

For more information see the project webpage at https://bitbucket.org/jonasmeyer/microprofile
